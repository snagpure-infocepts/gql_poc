package com.example.demo.entity;

import java.sql.Date;

public class InvoiceLineItem {
	String id;
	String businessId;
	String clientId;
	String invoiceId;
	String appointmentId;
	String employeeId;
	String patientId;
	String priceId;
	String name;
	long quantity;
	double extendedPrice;
	double discount;
	double subTotal;
	double taxAmount;
	Boolean deleted;
	Boolean declined;
	Date createdAt;
    Date     updatedAt;
    public InvoiceLineItem(String id, String businessId, String clientId, String invoiceId, String appointmentId,
			String employeeId, String patientId, String priceId, String name, long quantity, double extendedPrice,
			double discount, double subTotal, double taxAmount, Boolean deleted, Boolean declined, Date createdAt,
			Date updatedAt) {
		super();
		this.id = id;
		this.businessId = businessId;
		this.clientId = clientId;
		this.invoiceId = invoiceId;
		this.appointmentId = appointmentId;
		this.employeeId = employeeId;
		this.patientId = patientId;
		this.priceId = priceId;
		this.name = name;
		this.quantity = quantity;
		this.extendedPrice = extendedPrice;
		this.discount = discount;
		this.subTotal = subTotal;
		this.taxAmount = taxAmount;
		this.deleted = deleted;
		this.declined = declined;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
	}

	public String getBusinessId() {
		return businessId;
	}

	public void setBusinessId(String businessId) {
		this.businessId = businessId;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getAppointmentId() {
		return appointmentId;
	}

	public void setAppointmentId(String appointmentId) {
		this.appointmentId = appointmentId;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getPatientId() {
		return patientId;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getTaxAmount() {
		return taxAmount;
	}

	public void setTaxAmount(double taxAmount) {
		this.taxAmount = taxAmount;
	}

	public Boolean getDeleted() {
		return deleted;
	}

	public void setDeleted(Boolean deleted) {
		this.deleted = deleted;
	}

	public Boolean getDeclined() {
		return declined;
	}

	public void setDeclined(Boolean declined) {
		this.declined = declined;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	
	public InvoiceLineItem() {
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getInvoiceId() {
		return invoiceId;
	}

	public void setInvoiceId(String invoiceId) {
		this.invoiceId = invoiceId;
	}

	public String getPriceId() {
		return priceId;
	}

	public void setPriceId(String priceId) {
		this.priceId = priceId;
	}

	public long getQuantity() {
		return quantity;
	}

	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}

	public double getExtendedPrice() {
		return extendedPrice;
	}

	public void setExtendedPrice(double extendedPrice) {
		this.extendedPrice = extendedPrice;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public double getSubTotal() {
		return subTotal;
	}

	public void setSubTotal(double subTotal) {
		this.subTotal = subTotal;
	}

//	public InvoiceLineItem(String id, String invoiceId, String priceId, long quantity, double extendedPrice,
//			double discount, double subTotal) {
//		super();
//		
//		this.id = id;
//		this.invoiceId = invoiceId;
//		this.priceId = priceId;
//		this.quantity = quantity;
//		this.extendedPrice = extendedPrice;
//		this.discount = discount;
//		this.subTotal = subTotal;
//	}

	public String toString() {
		return "id :" + this.id + ", businessId :" + this.businessId + ", clientId :" + this.clientId + ",invoiceId :" + this.invoiceId + ",appointmentId :" + this.appointmentId + ",employeeId :" + this.employeeId + ",patientId :" + this.patientId + ", priceId :" + this.priceId + ",quantity : "
				+ this.quantity + ", extendedPrice :" + this.extendedPrice + ", discount :" + this.discount
				+ ", subtotal :" + this.subTotal;
	}

}

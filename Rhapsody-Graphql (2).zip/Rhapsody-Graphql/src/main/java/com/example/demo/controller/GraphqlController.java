package com.example.demo.controller;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;
import java.util.function.Consumer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.graphql.client.HttpGraphQlClient;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.demo.entity.Invoice;
import com.example.demo.entity.InvoiceLineItem;
import com.example.demo.repository.InvoiceLineItemList;
import com.example.demo.repository.InvoiceList;




@Controller
public class GraphqlController {
	@Autowired
	private Environment env;
	

	
	 
	
	
	Path fileName= Path.of("E:\\Petsmart\\key.txt");
	


	String str;
	@Bean
	HttpGraphQlClient httpGrpahQLClient() {
		try {
			 str = Files.readString(fileName);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return HttpGraphQlClient.builder().url("https://api.rhapsody.vet/graphql")
				.header("Authorization", str).build();
	}

	@Bean
	ApplicationRunner applicationRunner(HttpGraphQlClient hql) {
		return new ApplicationRunner() {
			
			
			@Override
			public void run(ApplicationArguments args) throws Exception {
			
				var httppReqDoc = """
						query {
							invoices (businessId : "AQVgxX1P"){
							    data{
							        id
						            businessId
							        clientId
							        patientId
							        appointmentId
						            employeeId
						            invoiceNo
						            name
                                    requiredDeposit
						            requiredDepositAmount
						            additionalDiscount
						            serviceFee
							        amount
							        totalTax
							        totalDiscount
							        serviceFeeAmount
						            deleted
						            createdAt
						            updatedAt
                     
							        items {
							            id
						                businessId
						                clientId
							            invoiceId
						                appointmentId
						                employeeId
						                patientId
							            priceId
						                name
							            quantity
							            extendedPrice
							            discount
						                taxAmount
							            subTotal
						                declined
						                deleted
						                createdAt
						                updatedAt
							        }
							    }
							}
						}

						""";
				// hql.document(httppReqDoc).execute().map(response => response.);
				
				hql.document(httppReqDoc).retrieve("invoices.data").toEntity(InvoiceList.class).
				subscribe(new Consumer<InvoiceList>() {

					@Override
					public void accept(InvoiceList t) {
						
						try {
							Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
						} catch (ClassNotFoundException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
				         Connection cnct = null;
				         try {
							cnct = DriverManager.getConnection("jdbc:mysql://localhost/Rhapsody","root","root123");
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
//				         Statement stmt = null;
//						try {
//							stmt = cnct.createStatement();
//						} catch (SQLException e1) {
//							// TODO Auto-generated catch block
//							e1.printStackTrace();
//						}
				 
//				         try {
//							ResultSet result=stmt.executeQuery("select * FROM Rhapsody.Invoice_Test  " );
//							 result.next();
//						} catch (SQLException e) {
//							// TODO Auto-generated catch block
//							e.printStackTrace();
//						}
				         PreparedStatement pstmt;
				         PreparedStatement pstmt1 = null;
				         PreparedStatement pstmt2;
						try {
							pstmt = cnct.prepareStatement("INSERT INTO fact_invoices_pa1 values (?, ?, ?, ?, ? ,?, ?, ?, ?, ? ,?, ?, ?, ?, ? ,?, ?, ?, ?, ? )");
							pstmt1 = cnct.prepareStatement("INSERT INTO fact_invoice_line_items_pa2 values (?, ?, ?, ?, ? ,?, ?, ?, ?, ? ,?, ?, ?, ?, ? ,?, ? )");
							pstmt2 =cnct.prepareStatement("INSERT INTO monitoring values (?, ?, ? )");
							Timestamp timestamp = null;
							Timestamp timestamp1=null;
						
							Timestamp timestamp3=null;
							for(Invoice i : t) {
								Iterator iterator = i.getItems().iterator();
								while(iterator.hasNext()) {
							         iterator.next();
							         
							      }
								System.out.println("*********"+i.getItems().get(0).getId());
						
								 timestamp = new Timestamp(System.currentTimeMillis());	
								String Id =i.getItems().get(0).getId();
								String BusinessId =i.getItems().get(0).getBusinessId();
								String InvoiceId=i.getItems().get(0).getInvoiceId();
								String ClientId =i.getItems().get(0).getClientId();
								String AppointmentId =i.getItems().get(0).getAppointmentId();
								String EmployeeId =i.getItems().get(0).getEmployeeId();
								String PatientId =i.getItems().get(0).getPatientId();
								String PriceId =i.getItems().get(0).getPriceId();
								String Name =i.getItems().get(0).getName();
								double Quantity =i.getItems().get(0).getQuantity();
								double ExtendedPrice = i.getItems().get(0).getExtendedPrice();
								double Discount = i.getItems().get(0).getDiscount();
								double taxAmount = i.getItems().get(0).getTaxAmount();
								double SubTotal = i.getItems().get(0).getSubTotal();
								 Boolean Deleted = i.getItems().get(0).getDeleted();
						            Date CreatedAt=i.getItems().get(0).getCreatedAt();
						            Date UpdatedAt=i.getItems().get(0).getUpdatedAt();
						            
						            pstmt1.setString(1, Id);
						            pstmt1.setString(2, BusinessId);
						            pstmt1.setString(3, InvoiceId);
						            pstmt1.setString(4, ClientId);
						            pstmt1.setString(5, AppointmentId);
						            pstmt1.setString(6, EmployeeId);
						            pstmt1.setString(7, PatientId);
						            pstmt1.setString(8, PriceId);
						            pstmt1.setString(9, Name);
						            pstmt1.setDouble(10, Quantity);
						            pstmt1.setDouble(11, ExtendedPrice);
						            pstmt1.setDouble(12, Discount);
						            pstmt1.setDouble(13, taxAmount);
						            pstmt1.setDouble(14, SubTotal);
						            pstmt1.setBoolean(15, Deleted);
						            pstmt1.setDate(16, CreatedAt);
						            pstmt1.setDate(17, UpdatedAt);
						            pstmt1.executeUpdate();
						             timestamp1 = new Timestamp(System.currentTimeMillis());
								
								
						        
								String id =  i.getId();
								String businessId =  i.getBusinessId();
								String appointmentId =  i.getAppointmentId();
								String employeeId = i.getEmployeeId();
					            String clientId = i.getClientId();
					            String patientId = i.getPatientId();
					            String invoiceNo = i.getInvoiceNo();
					            String name = i.getName();
					            double amount = i.getAmount();
					            double requiredDeposit = i.getRequiredDeposit();
					            double requiredDepositAmount = i.getRequiredDepositAmount();
					            double additionalDiscount = i.getAdditionalDiscount();
					            double serviceFee = i.getServiceFeeAmount();
					            double subtotal = i.getSubtotal();
					            double totalTax = i.getTotalTax();
					            double totalDiscount = i.getTotalDiscount();
					            double serviceFeeAmount = i.getServiceFeeAmount();
					            Boolean deleted = i.getDeleted();
					            Date createdAt=i.getCreatedAt();
					            Date updatedAt=i.getUpdatedAt();
					            pstmt.setString(1, id);
					            pstmt.setString(2, businessId);
					            pstmt.setString(3, appointmentId);
					            pstmt.setString(4, employeeId);
					            pstmt.setString(5, clientId);
					            pstmt.setString(6, patientId);
					            pstmt.setString(7, invoiceNo);
					            pstmt.setString(8, name);
					            pstmt.setDouble(9, amount);
					            pstmt.setDouble(10, requiredDeposit);
					            pstmt.setDouble(11, requiredDepositAmount);
					            pstmt.setDouble(12, additionalDiscount);
					            pstmt.setDouble(13, serviceFee);
					            pstmt.setDouble(14, subtotal);
					            pstmt.setDouble(15, totalTax);
					            pstmt.setDouble(16, totalDiscount);
					            pstmt.setDouble(17, serviceFeeAmount);
					            pstmt.setBoolean(18, deleted);
					            pstmt.setDate(19, createdAt);
					            pstmt.setDate(20, updatedAt);
					            pstmt.executeUpdate();
					             timestamp3 = new Timestamp(System.currentTimeMillis());
					          
							}
							pstmt2.setTimestamp(1, timestamp);
							pstmt2.setTimestamp(2, timestamp3);
							pstmt2.setString(3, "True");
							pstmt2.executeUpdate();
							 System.out.println(timestamp);
					            System.out.println(timestamp1);
					           
					            System.out.println(timestamp3);
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
				         //result.next();
						
						
						
						//   cnct.close();
				    	   
				    	   
				    	

					
				
					}
				});
				System.out.println("Testing");
//				hql.document(httppReqDoc).retrieve("invoices.data").toEntity(InvoiceLineItemList.class).
//				subscribe(new Consumer<InvoiceLineItemList>() {
//
//					@Override
//					public void accept(InvoiceLineItemList it) {
//						System.out.println("========================================================");
//						try {
//							Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//						} catch (ClassNotFoundException e1) {
//							// TODO Auto-generated catch block
//							e1.printStackTrace();
//						}
//				         Connection cnct = null;
//				         try {
//							cnct = DriverManager.getConnection("jdbc:mysql://localhost/Rhapsody","root","root123");
//						} catch (SQLException e1) {
//							// TODO Auto-generated catch block
//							e1.printStackTrace();
//						}
//				         Statement stmt = null;
//						try {
//							stmt = cnct.createStatement();
//						} catch (SQLException e1) {
//							// TODO Auto-generated catch block
//							e1.printStackTrace();
//						}
//				 
//				         try {
//							ResultSet result=stmt.executeQuery("select * FROM Rhapsody.Invoice_Test  " );
//							 result.next();
//						} catch (SQLException e) {
//							// TODO Auto-generated catch block
//							e.printStackTrace();
//						}
//				         PreparedStatement pstmt;
//						try {
//							pstmt = cnct.prepareStatement("INSERT INTO fact_invoices_pa1 values (?, ?, ?, ?, ? ,?, ?, ?, ?, ? ,?, ?, ?, ?, ? ,?, ?, ?, ?, ? )");
//							for(InvoiceLineItem i : it) {
//								
//								
//								
//							//	System.out.println("============"+i.getId());
//								
////								String id =  i.getId();
////								String businessId =  i.getBusinessId();
////								String appointmentId =  i.getAppointmentId();
////								String employeeId = i.getEmployeeId();
////					            String clientId = i.getClientId();
////					            String patientId = i.getPatientId();
////					            String invoiceNo = i.getInvoiceNo();
////					            String name = i.getName();
////					            double amount = i.getAmount();
////					            double requiredDeposit = i.getRequiredDeposit();
////					            double requiredDepositAmount = i.getRequiredDepositAmount();
////					            double additionalDiscount = i.getAdditionalDiscount();
////					            double serviceFee = i.getServiceFeeAmount();
////					            double subtotal = i.getSubtotal();
////					            double totalTax = i.getTotalTax();
////					            double totalDiscount = i.getTotalDiscount();
////					            double serviceFeeAmount = i.getServiceFeeAmount();
////					            Boolean deleted = i.getDeleted();
////					            Date createdAt=i.getCreatedAt();
////					            Date updatedAt=i.getUpdatedAt();
////					            pstmt.setString(1, id);
////					            pstmt.setString(2, businessId);
////					            pstmt.setString(3, appointmentId);
////					            pstmt.setString(4, employeeId);
////					            pstmt.setString(5, clientId);
////					            pstmt.setString(6, patientId);
////					            pstmt.setString(7, invoiceNo);
////					            pstmt.setString(8, name);
////					            pstmt.setDouble(9, amount);
////					            pstmt.setDouble(10, requiredDeposit);
////					            pstmt.setDouble(11, requiredDepositAmount);
////					            pstmt.setDouble(12, additionalDiscount);
////					            pstmt.setDouble(13, serviceFee);
////					            pstmt.setDouble(14, subtotal);
////					            pstmt.setDouble(15, totalTax);
////					            pstmt.setDouble(16, totalDiscount);
////					            pstmt.setDouble(17, serviceFeeAmount);
////					            pstmt.setBoolean(18, deleted);
////					            pstmt.setDate(19, createdAt);
////					            pstmt.setDate(20, updatedAt);
////					            pstmt.executeUpdate();
//								
//							}
//						} catch (SQLException e1) {
//							// TODO Auto-generated catch block
//							e1.printStackTrace();
//						}
//				         //result.next();
//						
//					//	System.out.println("=================="+it);
//						
//						
//				    	   
//				    	   
//				    	   
//
//					
//				
//					}
//				});
			}
		};
	}

}

package com.example.demo.entity;

import java.sql.Date;
import java.util.List;


public class Invoice {
	String id;
	String businessId;
	String clientId;
	String patientId;
	String appointmentId;
	String employeeId;
	String invoiceNo;
	String name;
	double requiredDeposit;
	double requiredDepositAmount;
	double additionalDiscount;
	double serviceFee;
	double amount;
	double subtotal;
	double totalTax;
	double totalDiscount;
	double serviceFeeAmount;
	Boolean deleted;
    Date createdAt;
    Date     updatedAt;
	List<InvoiceLineItem> items;

	public Invoice(String id, String businessId, String clientId, String patientId, String appointmentId,
			String employeeId, String invoiceNo, String name, double requiredDeposit, double requiredDepositAmount,
			double additionalDiscount, double serviceFee, double amount, double subtotal, double totalTax,
			double totalDiscount, double serviceFeeAmount, Boolean deleted, Date createdAt, Date updatedAt,
			List<InvoiceLineItem> items) {
		super();
		this.id = id;
		this.businessId = businessId;
		this.clientId = clientId;
		this.patientId = patientId;
		this.appointmentId = appointmentId;
		this.employeeId = employeeId;
		this.invoiceNo = invoiceNo;
		this.name = name;
		this.requiredDeposit = requiredDeposit;
		this.requiredDepositAmount = requiredDepositAmount;
		this.additionalDiscount = additionalDiscount;
		this.serviceFee = serviceFee;
		this.amount = amount;
		this.subtotal = subtotal;
		this.totalTax = totalTax;
		this.totalDiscount = totalDiscount;
		this.serviceFeeAmount = serviceFeeAmount;
		this.deleted = deleted;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
		this.items = items;
	}

//	public Invoice(String id, String clientId, String patientId, String appointmentId, String invoiceNo, String name,
//			double amount, double subtotal, double totalTax, double totalDiscount, double serviceFeeAmount,
//			List<InvoiceLineItem> items) {
//		super();
//		this.id = id;
//		this.clientId = clientId;
//		this.patientId = patientId;
//		this.appointmentId = appointmentId;
//		this.invoiceNo = invoiceNo;
//		this.name = name;
//		this.amount = amount;
//		this.subtotal = subtotal;
//		this.totalTax = totalTax;
//		this.totalDiscount = totalDiscount;
//		this.serviceFeeAmount = serviceFeeAmount;
//		this.items = items;
//	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getPatientId() {
		return patientId;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public String getAppointmentId() {
		return appointmentId;
	}

	public void setAppointmentId(String appointmentId) {
		this.appointmentId = appointmentId;
	}

	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public double getSubtotal() {
		return subtotal;
	}

	public void setSubtotal(double subtotal) {
		this.subtotal = subtotal;
	}

	public double getTotalTax() {
		return totalTax;
	}

	public void setTotalTax(double totalTax) {
		this.totalTax = totalTax;
	}

	public double getTotalDiscount() {
		return totalDiscount;
	}

	public void setTotalDiscount(double totalDiscount) {
		this.totalDiscount = totalDiscount;
	}

	public double getServiceFeeAmount() {
		return serviceFeeAmount;
	}

	public void setServiceFeeAmount(double serviceFeeAmount) {
		this.serviceFeeAmount = serviceFeeAmount;
	}
	public String getBusinessId() {
		return businessId;
	}

	public void setBusinessId(String businessId) {
		this.businessId = businessId;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public double getRequiredDeposit() {
		return requiredDeposit;
	}

	public void setRequiredDeposit(double requiredDeposit) {
		this.requiredDeposit = requiredDeposit;
	}

	public double getRequiredDepositAmount() {
		return requiredDepositAmount;
	}

	public void setRequiredDepositAmount(double requiredDepositAmount) {
		this.requiredDepositAmount = requiredDepositAmount;
	}

	public double getAdditionalDiscount() {
		return additionalDiscount;
	}

	public void setAdditionalDiscount(double additionalDiscount) {
		this.additionalDiscount = additionalDiscount;
	}

	public double getServiceFee() {
		return serviceFee;
	}

	public void setServiceFee(double serviceFee) {
		this.serviceFee = serviceFee;
	}

	public Boolean getDeleted() {
		return deleted;
	}

	public void setDeleted(Boolean deleted) {
		this.deleted = deleted;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public List<InvoiceLineItem> getItems() {
		return items;
	}

	public void setItems(List<InvoiceLineItem> items) {
		this.items = items;
	}

	public Invoice() {
	}

	public String toString() {
		return "id :" + this.id + ",employeeId :" + this.employeeId + ", businessId :" + this.businessId + ",clientId :" + this.clientId + ", patientId :" + this.patientId + "appointmentId : "
				+ this.appointmentId + ", invoiceNo :" + this.invoiceNo + ", name :" + this.name + ", amount :"
				+ this.amount;
	}

}

package com.example.demo.repository;

import java.util.ArrayList;

import com.example.demo.entity.InvoiceLineItem;



public class InvoiceLineItemList extends ArrayList<InvoiceLineItem> {
	@Override
	public void add(int index, InvoiceLineItem element) {
		super.add(index, element);
	}
	
	@Override
	public InvoiceLineItem get(int index) {
		return super.get(index);
	}
}

package com.example.demo.repository;

import java.util.ArrayList;

import com.example.demo.entity.Invoice;



public class InvoiceList extends ArrayList<Invoice>{
	@Override
	public void add(int index, Invoice element) {
		super.add(index, element);
	}
	
	@Override
	public Invoice get(int index) {
		return super.get(index);
	}
}
